Proyecto 3 de Javier Damiani - Practicum
El proyecto consiste en realizar una página web en la cual se trata el tema del aprendizaje. Se usa css para editar el estilo de la página web, todo el desarrollo del mismo se hizo en el programa VSCode para Mac, asimismo, se utilizó la tecnología HTML y CSS.
Por otro lado, para el desarrollo del proyecto se utilizó como base el diseño realizado en el programa Figma, se tuvieron en cuenta las medidas proporcionadas por el programa
